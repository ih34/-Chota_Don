#!/usr/bin/env python3
"""wireframes/wireframes.html -> wireframes/Rozana-Wireframes.pdf (pip install playwright pypdf; playwright install chromium)"""
import pathlib
from playwright.sync_api import sync_playwright
from pypdf import PdfReader, PdfWriter
root = pathlib.Path(__file__).resolve().parents[1]
src = (root / "wireframes/wireframes.html").resolve().as_uri()
out = root / "wireframes/Rozana-Wireframes.pdf"
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(); pg.goto(src); pg.wait_for_timeout(300)
    pg.pdf(path=str(out), prefer_css_page_size=True, print_background=True); b.close()
r = PdfReader(str(out)); w = PdfWriter()
for page in r.pages:
    if page.extract_text().strip(): w.add_page(page)
w.write(str(out)); print("pdf pages", len(w.pages))
