#!/usr/bin/env python3
"""Assemble the single-file prototype: index.html = template + phone.css + app.js + inlined logo."""
import base64, pathlib
root = pathlib.Path(__file__).resolve().parents[1]
tpl = (root / "src/template.html").read_text()
css = (root / "src/phone.css").read_text()
js = (root / "src/app.js").read_text()
logo = base64.b64encode((root / "assets/meesho-logo-96.png").read_bytes()).decode()
js = 'window.ROZANA_LOGO="data:image/png;base64,' + logo + '";\n' + js
out = tpl.replace("__PHONECSS__", css).replace("__APPJS__", js)
(root / "index.html").write_text(out)
print("built index.html", len(out), "bytes")
