// Render the app's screens into a screens-only PDF (needs: node, python3 + playwright chromium).
// Usage: node scripts/wireframes.js && python3 scripts/pdf.py
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..');
globalThis.localStorage = { getItem: () => null, setItem: () => {} };
globalThis.document = { getElementById: () => null, addEventListener: () => {}, querySelector: () => null };
globalThis.ROZANA_LOGO = 'data:image/png;base64,' + fs.readFileSync(path.join(root, 'assets/meesho-logo-96.png')).toString('base64');
eval(fs.readFileSync(path.join(root, 'src/app.js'), 'utf8'));
const R = globalThis.ROZANA, DAY = 86400000, css = fs.readFileSync(path.join(root, 'src/phone.css'), 'utf8');
const pages = []; const add = (title, fn) => pages.push({ title, html: fn() });
let S = R.fresh(); R.setState(S);
add('Home', () => R.V.home()); add('My lists', () => R.V.lists());
S.lists = [{ id: 'L1', name: 'Household Monthly Restock', cadence: 'monthly', items: R.STARTERS[1].items.map(id => ({ id, on: true, q: 1 })) }]; S.activeList = 'L1'; S.lists[0].items[4].on = false;
add('Rozana List', () => R.V.list());
S.snap = { stage: 'idle', lines: [], picks: {} }; add('Snap-a-List: upload', () => R.V.snap());
S.snap = { stage: 'lines', lines: R.SAMPLE_LINES.slice(), picks: {} }; add('Snap-a-List: recognised lines', () => R.V.snap());
S.snap = { stage: 'results', lines: R.SAMPLE_LINES.slice(), picks: { 'Toothpaste': 'tp1', 'Hair oil (nariyal)': 'oil', '2 notebooks': 'nb' } }; add('Snap-a-List: choose one per line', () => R.V.snap());
S.cat = 'bath'; add('Shop', () => R.V.shop());
S.product = 'oil'; S.basket = { oil: { q: 1, shop: 'gupta' } }; add('Product', () => R.V.product());
S.basket = { tp1: { q: 1, shop: 'gupta' }, det1: { q: 1, shop: 'sharma' }, soap: { q: 1, shop: 'gupta' }, oil: { q: 1, shop: 'gupta' }, sham: { q: 1, shop: 'sharma' }, razor: { q: 1, shop: 'gupta' } };
add('Checkout', () => R.V.checkout());
const t0 = new Date(); t0.setHours(14, 0, 0, 0);
S.orders = [{ id: 'RZ1001', items: Object.keys(S.basket).map(id => ({ id, q: 1, shop: S.basket[id].shop, price: R.best(R.CATALOG.find(p => p.id === id))[1] })), shops: ['gupta', 'sharma'], subtotal: 681, savings: 171, total: 681, payment: 'cod', placedAt: t0.getTime() - 1.4 * DAY, rozanaDay: t0.getTime() + 1.6 * DAY, delivered: false }];
S.basket = {}; add('Order placed', () => R.V.confirmed()); add('Order tracking', () => R.V.orders());
S.orders[0].delivered = true; S.orders[0].deliveredAt = S.orders[0].rozanaDay; S.offset = 26 * DAY; add('Routine and refill nudge', () => R.V.account());
const rows = []; for (let i = 0; i < pages.length; i += 3) rows.push(pages.slice(i, i + 3));
const doc = `<!doctype html><html><head><meta charset="utf-8"><style>
@page{size:A4 landscape;margin:0}body{margin:0;font-family:Mulish,Arial,sans-serif;color:#1f1f1f}
.pg{width:297mm;height:210mm;box-sizing:border-box;display:flex;align-items:center;justify-content:space-evenly;padding:8mm 10mm;background:#fff}.pg+.pg{page-break-before:always}
.cell{display:flex;flex-direction:column;align-items:center;gap:3mm}.cap{font-size:11px;color:#5c5c5c;font-weight:600}
.frame{width:390px;height:844px;transform:scale(0.78);transform-origin:center;flex-shrink:0;border:6px solid #2b1d27;border-radius:28px;overflow:hidden;background:#fff;display:flex;flex-direction:column}
.fw{width:calc(390px*0.78 + 12px);height:calc(844px*0.78 + 12px);display:flex;align-items:center;justify-content:center;flex-shrink:0}
${css}.scr{flex-grow:1}</style></head><body>
${rows.map(r => `<div class="pg">${r.map(p => `<div class="cell"><div class="fw"><div class="frame"><div class="scr">${p.html}</div></div></div><div class="cap">${p.title}</div></div>`).join('')}</div>`).join('')}
</body></html>`;
fs.writeFileSync(path.join(root, 'wireframes/wireframes.html'), doc);
console.log('wrote wireframes/wireframes.html with', pages.length, 'screens');
